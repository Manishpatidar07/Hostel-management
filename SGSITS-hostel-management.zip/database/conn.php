<?php

$servername = "localhost:3307";
$username = "root";
$password = "";
$dbname = "hms";

$conn = mysqli_connect($servername, $username, $password, $dbname);

if (!$conn) {
    die("Connection failed: " . mysqli_connect_error());
}
// No closing PHP tag here to avoid unintended output

// Rest of your PHP code or HTML goes here

