
function messdetails(){
  window.location.href ="mess.php";
}
function requests(){
  window.location.href ="leaverequests.php";
}
function addstudent(){
  window.location.href ="notice.html";
}
